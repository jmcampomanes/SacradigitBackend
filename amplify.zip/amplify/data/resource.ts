import { type ClientSchema, a, defineData } from '@aws-amplify/backend';

/**
 * TEMPORARY — RBAC removed for testing.
 * Every model is open to anyone with the API key (no sign-in
 * required). This is NOT secure for real parishioner data —
 * restore allow.owner()/allow.groups() before this app is used
 * for real.
 */
const schema = a.schema({

  ParishRecord: a.model({
    type: a.enum(['baptism', 'confirmation', 'marriage', 'death']),
    fullName: a.string().required(),
    dateOfEvent: a.date(),
    officiant: a.string(),
    status: a.enum(['digitized', 'processing', 'queued']),
    fileURL: a.string(),
    addedByName: a.string(),
  }).authorization(allow => [allow.publicApiKey()]),

  CertificateRequest: a.model({
    requesterName: a.string().required(),
    certificateType: a.string().required(),
    purpose: a.string(),
    notes: a.string(),
    details: a.json(),           // dynamic fields per cert type (baptized name, dates, etc.)
    status: a.enum(['pending', 'approved', 'released', 'rejected']),
    rejectionReason: a.string(),
    linkedRecordId: a.id(),
  }).authorization(allow => [allow.publicApiKey()]),

  Mass: a.model({
    date: a.date().required(),
    time: a.string().required(),
    type: a.enum(['daily', 'anticipated', 'special', 'binyag']),
    title: a.string(),
    officiant: a.string(),
    location: a.string(),
    isSpecial: a.boolean().default(false),
    note: a.string(),
  }).authorization(allow => [allow.publicApiKey()]),

  // One row per day of the week — the recurring pattern shown in
  // "Regular Weekly Mass Schedule" on both the admin Masses page and
  // the parishioner Mass Schedule page. A day with no row yet just
  // falls back to a hardcoded default in the frontend (see
  // weekly-mass-schedule.js) until an admin edits and saves it here.
  WeeklyMassSchedule: a.model({
    dayOfWeek: a.enum(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']),
    times: a.json(),             // array of "h:mm AM/PM" strings, e.g. ["6:00 AM", "7:00 AM"]
    massType: a.enum(['daily', 'anticipated', 'special', 'binyag']),
    label: a.string(),           // optional override title (e.g. "Sunday Mass"); falls back to massType's label
  }).authorization(allow => [allow.publicApiKey()]),

  MassIntention: a.model({
    donor: a.string().required(),
    type: a.string(),
    names: a.json(),          // array of names the intention is for
    startTime: a.string(),
    endTime: a.string(),
    massDate: a.date(),        // assigned mass date, null until scheduled
    massTime: a.string(),
    offering: a.float(),
    status: a.enum(['pending', 'scheduled', 'completed']),
  }).authorization(allow => [allow.publicApiKey()]),

  FacilityBooking: a.model({
    requesterName: a.string(),
    facilityName: a.string().required(),
    date: a.date().required(),
    startTime: a.string(),
    endTime: a.string(),
    purpose: a.string(),
    attendees: a.integer(),
    notes: a.string(),
    status: a.enum(['pending', 'approved', 'declined']),
  }).authorization(allow => [allow.publicApiKey()]),

  Donation: a.model({
    donor: a.string(),
    amount: a.float().required(),
    method: a.string(),
    purpose: a.string(),
    date: a.date(),
    anonymous: a.boolean().default(false),
  }).authorization(allow => [allow.publicApiKey()]),

  Announcement: a.model({
    title: a.string().required(),
    body: a.string().required(),
    audience: a.string(),
    published: a.boolean().default(true),
    media: a.json(),
  }).authorization(allow => [allow.publicApiKey()]),

  Blessing: a.model({
    requesterName: a.string().required(),
    type: a.string().required(),
    location: a.string(),
    contact: a.string(),
    notes: a.string(),
    details: a.json(),           // dynamic fields per service type (child's name, address, etc.)
    status: a.enum(['pending', 'scheduled', 'completed', 'declined']),
    preferredDate: a.date(),
    date: a.date(),
    time: a.string(),
    declineReason: a.string(),
  }).authorization(allow => [allow.publicApiKey()]),

  CloudFile: a.model({
    name: a.string().required(),
    url: a.string().required(),
    folder: a.string(),
    bytes: a.integer(),
  }).authorization(allow => [allow.publicApiKey()]),

  SpecialSchedule: a.model({
    name: a.string().required(),
    type: a.string(),
    status: a.string(),
    startDate: a.date(),
    endDate: a.date(),
    note: a.string(),
  }).authorization(allow => [allow.publicApiKey()]),

  AccessLog: a.model({
    userName: a.string(),
    fileName: a.string(),
    action: a.string(),
  }).authorization(allow => [allow.publicApiKey()]),

  Role: a.model({
    role: a.string().required(),
    permissions: a.json(),
    users: a.string(),
  }).authorization(allow => [allow.publicApiKey()]),

});

export type Schema = ClientSchema<typeof schema>;

export const data = defineData({
  schema,
  authorizationModes: {
    defaultAuthorizationMode: 'apiKey',
    apiKeyAuthorizationMode: { expiresInDays: 30 },
  },
});