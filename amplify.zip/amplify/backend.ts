import { defineBackend } from '@aws-amplify/backend';
import { auth } from './auth/resource';
import { data } from './data/resource';
import { storage } from './storage/resource';

/**
 * After `npx ampx sandbox` deploys this, go to:
 * AWS Console -> Cognito -> User pools -> (your pool) -> Groups
 * and create two groups: "staff" and "admin".
 * Assign yourself to "admin" so you can test the admin pages.
 * (Equivalent to setting role: 'admin' on a Firestore /users/{uid} doc.)
 */
defineBackend({
  auth,
  data,
  storage,
});